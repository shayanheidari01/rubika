from .accounts.client import _Client as Client


__version__ = '5.0.1b'
__author__ = 'Shayan Heidari'