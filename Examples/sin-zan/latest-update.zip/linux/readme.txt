Two versions are available for two versions of Python on Linux!

The bot3-8.py file is for Python version 3.8
The bot3-9.py file is for Python version 3.9

Tested on version 3.8 and 3.9 and run the bot in 64-bit Python