It is for Windows and use Python version 3.10

Tested on Python version 3.10.8

Try on 64 bit