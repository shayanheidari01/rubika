'''
In line 8, enter your ID (AUTH).
In line 9, copy your post link and paste it there
Then run the bot.py file
'''

class Information:
    auth: str = ''
    post: str = ''